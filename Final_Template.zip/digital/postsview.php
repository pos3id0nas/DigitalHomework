<?php


$sql = "SELECT * FROM posts ORDER BY postid DESC";
    $query = mysqli_query($conn, $sql);;
	
	
?>