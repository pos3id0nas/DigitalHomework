<?php
include("errors.php");
include('config.php');

session_start();

if(isset($_SESSION['username'])) 
{
	setcookie('username', "", time() + (1200), "/"); 
	
    //if(isset($_SESSION['speciality'])&& $_SESSION['speciality'] == 1) {header("Location: profile.php");}
	//else if (isset($_SESSION['speciality'])&& $_SESSION['speciality'] == 0) {header("Location: stu-edit-profile.php");}	
}

else{header("location: ../index.php");
	setcookie(session_name(), '', 1200);
	session_unset();
	session_destroy();
	$_SESSION = array();
	}

?>