<?php
/* Database connection start */
$servername = "localhost";
$user_name = "admin";
$password = "1q2w3e4r5t!";
$dbname = "digitalhomework";
$conn = mysqli_connect($servername, $user_name, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

?>
