<?php 
include('errors.php');

if (isset($_POST['submit'])) {
	$email = $conn->real_escape_string($_POST['email']);
	$password = $conn->real_escape_string($_POST['password']);
	$password = hash('sha256', $password);

	$sql  = "SELECT * FROM user WHERE email='$email' AND password='$password' UNION SELECT * FROM authors WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		$logintime = "UPDATE user SET lastLogin = now() where email = '$email'";
		mysqli_query($conn, $logintime);
		$_SESSION['speciality'] = $row['speciality'];
		$_SESSION['Joined'] = $row['Joined'];
		$_SESSION['fullname'] = $row['fullname'];
		if($_SESSION['speciality']==1) {header("location: professor/home.php");}
		else{header("location: student/home.php");}
		exit();
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}
}


?>