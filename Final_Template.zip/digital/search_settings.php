<?php

include('errors.php');


		if(isset($_GET['search']))
		{
			$searchbar = $_GET['search'];
			$sql = "SELECT * FROM posts WHERE CONCAT(title,sdesc) LIKE '%$searchbar%' ";
			$query = mysqli_query($conn,$sql);
			if(!empty($_GET['search']) && !empty($_GET['lessonname']))
			{
			$lessonname= $_GET['lessonname'];
			$sql = "SELECT * FROM posts WHERE CONCAT(title,sdesc) LIKE '%$searchbar%' AND post_lesson LIKE'%$lessonname%' ";
			$query = mysqli_query($conn,$sql);
			}
			if(!empty($_GET['search']) && !empty($_GET['lessonname']) && !empty($_GET['fullname']))
			{
			$fullname= $_GET['fullname'];
			$sql = "SELECT * FROM posts WHERE CONCAT(title,sdesc) LIKE '%$searchbar%' AND post_lesson LIKE'%$lessonname%' AND author LIKE'%$fullname%'";
			$query = mysqli_query($conn,$sql);
			}
			if(empty($_GET['search']) && empty($_GET['lessonname']) && !empty($_GET['fullname']))
			{
			$fullname= $_GET['fullname'];	
			$sql = "SELECT * FROM posts WHERE author LIKE'%$fullname%' ";
			$query = mysqli_query($conn,$sql);
			}
			if(empty($_GET['search']) && !empty($_GET['lessonname']) && empty($_GET['fullname']))
			{
			$lessonname= $_GET['lessonname'];	
			$sql = "SELECT * FROM posts WHERE post_lesson LIKE'%$lessonname%' ";
			$query = mysqli_query($conn,$sql);
			}
			
		}

		else
		{	

			$sql = "SELECT * FROM posts";
			$query = mysqli_query($conn,$sql);
		}
	
	

?>