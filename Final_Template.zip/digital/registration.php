<?php

include('errors.php');
include('config.php');
session_start();

if (isset($_POST['submit'])) {
	$firstName = $conn->real_escape_string($_POST['firstName']);
	$lastName = $conn->real_escape_string($_POST['lastName']);
	$email = $conn->real_escape_string($_POST['email']);
	$speciality = $conn->real_escape_string($_POST['speciality']);
	$password = $conn->real_escape_string($_POST['password']);
	$confirm_password = $_POST['confirm_password'];	
	if (!preg_match("/^[a-zA-Z ]+$/",$firstName)) {
		$error = true;
		$uname_error = "Name must contain only alphabets and space";
	}
	if (!preg_match("/^[a-zA-Z ]+$/",$lastName)) {
		$error = true;
		$uname_error = "Name must contain only alphabets and space";
	}
	if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		$error = true;
		$email_error = "Please Enter Valid Email ID";
	}
	if(strlen($password) < 6) {
		$error = true;
		$password_error = "Password must be minimum of 6 characters";
	}
	if($password != $confirm_password) {
		$error = true;
		$confirm_password = "Password and Confirm Password doesn't match";
	}
	$a1 = explode("@", $email);
    $username = $a1[0];
	$fullname = $firstName.' '.$lastName; 
	if (!$error) {
		$password = hash('sha256', $password);
		$currentdate = date('Y  m  d');
		//Student
		if($speciality == 0)
		{
		$SQL_INSERT = "INSERT INTO user (username, firstName, lastName, fullname, email, speciality, password, Joined) VALUES (?,?,?,?,?,?,?,?)";
		$stmt = $conn->prepare($SQL_INSERT);
		if($stmt = $conn->prepare($SQL_INSERT)) { 
		$stmt->bind_param("sssssiss", $username, $firstName, $lastName, $fullname, $email, $speciality, $password, $currentdate);
		$stmt->execute();
		
		header("location: student/home.php");
		exit();
		//Professor
		} else {
                $error = $conn->error . ' ' . $conn->error;
                echo $error;
				$error_message = "Error in registering...Please try again later!";
            }
		}
		else if($speciality == 1)
		{
			$SQL_INSERT = "INSERT INTO authors (username, firstName, lastName, fullname, email, speciality, password, Joined, phone) VALUES (?,?,?,?,?,?,?,?,?)";
		$stmt = $conn->prepare($SQL_INSERT);
		if($stmt = $conn->prepare($SQL_INSERT)) { 
		$stmt->bind_param("sssssiss", $username, $firstName, $lastName, $fullname, $email, $speciality, $password, $currentdate);
		$stmt->execute();
		header("location: professor/home.php");
		exit();
		} else {
                $error = $conn->error . ' ' . $conn->error;
                echo $error;
				$error_message = "Error in registering...Please try again later!";
            }
		}
		}
	}
?>