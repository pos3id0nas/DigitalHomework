<?php 
include("../session.php");
if($_SESSION["speciality"]!=0){header('Location: ../professor/home.php');}

include('../droplists_options.php');
include('../search_settings.php');

?>
<!DOCTYPE html>
<html lang="gr">
<head>

  <!-- SITE TITTLE -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Τμήμα Ψηφιακών Συστήματων</title>
  
  <!-- FAVICON -->
  <link href="../images/favicon.png" rel="shortcut icon">
  <!-- PLUGINS CSS STYLE -->
  <!-- <link href="plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet"> -->
  <!-- Bootstrap -->
  <link rel="stylesheet" href="../plugins/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../plugins/bootstrap/css/bootstrap-slider.css">
  <!-- Font Awesome -->
  <link href="../plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Owl Carousel -->
  <link href="../plugins/slick-carousel/slick/slick.css" rel="stylesheet">
  <link href="../plugins/slick-carousel/slick/slick-theme.css" rel="stylesheet">
  <!-- Fancy Box -->
  <link href="../plugins/fancybox/jquery.fancybox.pack.css" rel="stylesheet">
  <link href="../plugins/jquery-nice-select/css/nice-select.css" rel="stylesheet">
  <!-- CUSTOM CSS -->
  <link href="../css/style.css" rel="stylesheet">


  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>

<body class="body-wrapper">


<section>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<nav class="navbar navbar-expand-lg navbar-light navigation">
					<a class="navbar-brand" href="../student/home.php">
						<img src="../images/logo.png" alt="">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
					 aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav ml-auto main-nav ">
							<li class="nav-item active">
								<a class="nav-link" href="../student/home.php">Αρχική</a>
							</li>
							<li class="nav-item dropdown dropdown-slide">
								<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="">Ανακοινώσεις<span><i class="fa fa-angle-down"></i></span>
								</a>

								<!-- Dropdown list -->
								<div class="dropdown-menu">
									<!-- <a class="dropdown-item" href="dashboard.html">Ανακοινώσεις</a> -->
									<a class="dropdown-item" href="dashboard-my-ads.html">Ανακοινώσεις Τμήματος</a>
									<a class="dropdown-item" href="dashboard-favourite-ads.html">Ανακοινώσεις Καθηγητών</a>
									<a class="dropdown-item" href="dashboard-archived-ads.html">Ανακοινώσεις Μαθήματων</a>
									<!-- <a class="dropdown-item" href="dashboard-pending-ads.html">Dashboard Pending Ads</a> -->
								</div>
							</li>
							<li class="nav-item active">
								<a class="nav-link" href="../student/aboutus.php">Τμήμα</a>
							</li>
							<li class="nav-item active">
								<a class="nav-link" href="../student/contactus.php">Επικοινωνία</a>
							</li>
						</ul>
						<ul class="navbar-nav ml-auto mt-10">
							<li class="nav-item">
								<a class="nav-link text-white add-button" href="../student/profile.php"><?php echo $_SESSION['username'];?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link login-button" href="../logout.php">Εξοδος</a>
							</li>
						</ul>
					</div>
				</nav>
			</div>
		</div>
	</div>
</section>
<!--===============================
=            Hero Area            =
================================-->

<section class="hero-area bg-1 text-center overly">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Header Contetnt -->
				<div class="content-block">
					<h1>Ιστοσελίδα Ανακοινώσεων </h1>
					<p>Τμήματος Ψηφιακών Συστήματων Σπάρτης</p>
					<div class="short-popular-category-list text-center">
						<h2>Δημοφιλης Ανακοινωσεις</h2>
						<ul class="list-inline">
							<li class="list-inline-item">
								<a href="../category.html"><i class="fa fa-bed"></i> Καθηγητές</a></li>
							<li class="list-inline-item">
								<a href="../category.html"><i class="fa fa-grav"></i> Τμήμα</a>
							</li>
							<li class="list-inline-item">
								<a href="../category.html"><i class="fa fa-car"></i> Μαθήματα</a>
							</li>
							<!--<li class="list-inline-item">
								<a href="category.html"><i class="fa fa-cutlery"></i> Restaurants</a>
							</li>
							<li class="list-inline-item">
								<a href="category.html"><i class="fa fa-coffee"></i> Cafe</a>
							</li>-->
						</ul>
					</div>
					
				</div>
				<!-- Advance Search -->
				<div class="advance-search">
						<div class="container">
							<div class="row justify-content-center">
								<div class="col-lg-12 col-md-12 align-content-center">
										<form>
											<div class="form-row">
												<div class="form-group col-md-4">
													<input type="text" name="search" "<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>"id ="search"  class="form-control my-2 my-lg-1" id="inputtext4" placeholder="Αναζήτηση ...">
												</div>
												<div class="form-group col-md-3">
													<select name ="lessonname" class="w-100 form-control mt-lg-1 mt-md-2">
														<!--<option>Κατηγορίες</option>-->
														<option value="">Μάθημα</option>
														<?php while ($row = mysqli_fetch_array($resultl)):; ?>
																<option value="<?php echo $row[1];?>"><?php echo $row[1];?></option>
														<?php endwhile; ?>
													</select>
												</div>
												<div class="form-group col-md-3">
													<select name="fullname" class="w-100 form-control mt-lg-1 mt-md-2">
														<!--<option>Κατηγορίες</option>-->
														<option value="">Καθηγητης</option>
														<?php while ($row = mysqli_fetch_array($resultf)):; ?>
																<option value="<?php echo $row[4];?>"><?php echo $row[4];?></option>
														<?php endwhile; ?>
													</select>
												</div>
												<div class="form-group col-md-2 align-self-center">
													<button type="submit" class="btn btn-primary">Αναζήτηση.</button>
												</div>
											</div>
										</form>
									</div>
								</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>


<!--===========================================
=                 Latest Posts                =
============================================-->

<section class="popular-deals section bg-5">
	<div class="container">
			
				<div class="section-title ">
					<h2-news>Τελευταίες Ανακοινώσεις</h2-news>
				</div>
		</div>
		<section class="blog-me pt-100 pb-100" id="blog">
         <div class="container">
            <div class="row">
			<?php foreach($query as $q){?>
               <div class="col-lg-12 col-md-6">
                  <!-- Single Blog -->
                  <div class="single-blog mb-200">
                     <div class="blog-img">
                        <img src="<?php echo $q['img'];?>" alt="">
                        <div class="post-category">
                           <a href="#"><?php echo $q['post_lesson'];?></a>
                        </div>
                     </div>
                     <div class="blog-content">
                        <div class="blog-title">
                           <h4><a href="#"><?php echo $q['title'];?></a></h4>
                           <div class="meta">
                              <ul>
                                 <li><?php echo $q['postdate'];?></li>
                              </ul>
                           </div>
                        </div>
                        <p><?php echo $q['sdesc'];?></p>
						<a href="#">Απο: <?php echo $q['author'];?></a>
                        <p><a href="view.php?id=<?php echo $q['postid'];?>" class="box_btn">read more</a></p>
                     </div>
                  </div>
               </div>
			<?php }?>
               <!--<div class="col-lg-12 col-md-6 mb-200">
                  
		 <!-- pagination
			    
				<div class="pagination justify-content-center">
						<ul class="pagination">
							<li class="page-item">
								<a class="page-link" href="#" aria-label="Previous">
									<span aria-hidden="true">&laquo;</span>
									<span class="sr-only">Previous</span>
								</a>
							</li>
							<li class="page-item"><a class="page-link" href="#">1</a></li>
							<li class="page-item active"><a class="page-link" href="#">2</a></li>
							<li class="page-item"><a class="page-link" href="#">3</a></li>
							<li class="page-item">
								<a class="page-link" href="#" aria-label="Next">
									<span aria-hidden="true">&raquo;</span>
									<span class="sr-only">Next</span>
								</a>
							</li>
						</ul>
					</nav>
				</div>
				pagination -->
			</div>
		</div>	
      </section>
</section>

<!--==========================================
=            All Category Section            =
===========================================-->



<!--====================================
=            NewsLetter            =
=====================================-->

<section class="call-to-action overly bg-3 section-sm">
	<!-- Container Start -->
	<div class="container">
	<html>
		<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Untitled</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
		<link rel="stylesheet" href="../assets/css/style.css">
		</head>

		<body>
			<div class="newsletter-subscribe">
				<div class="container">
					<div class="intro">
						<h2 class="text-center">Subscribe for our Newsletter</h2>
						<p class="text-center">Nunc luctus in metus eget fringilla. Aliquam sed justo ligula. Vestibulum nibh erat, pellentesque ut laoreet vitae. </p>
					</div>
					<form class="form-inline" method="post">
						<div class="form-group"><input class="form-control" type="email" name="email" placeholder="Your Email"></div>
						<div class="form-group"><button class="btn btn-primary" type="submit">Subscribe </button></div>
					</form>
				</div>
			</div>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
		</body>

	</html>
	</div>
	<!-- Container End -->
</section>

<!--============================
=            Footer            =
=============================-->

<footer class="footer section section-sm">
  <!-- Container Start -->
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-7 offset-md-1 offset-lg-0">
        <!-- About -->
        <div class="block about">
          <!-- footer logo -->
          <img src="../images/logo-footer.png" alt="">
          <!-- description -->
          <!--<p class="alt-color">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
            laboris nisi ut aliquip ex ea commodo consequat.</p>-->
        </div>
      </div>
      <!-- Link list -->
      <div class="col-lg-2 offset-lg-1 col-md-3">
        <div class="block">
          <h4>Site Pages</h4>
          <ul>
            <li><a href="#">Boston</a></li>
            <li><a href="#">How It works</a></li>
            <li><a href="#">Deals & Coupons</a></li>
            <li><a href="#">Articls & Tips</a></li>
            <li><a href="terms-condition.html">Terms & Conditions</a></li>
          </ul>
        </div>
      </div>
      <!-- Link list -->
      <div class="col-lg-2 col-md-3 offset-md-1 offset-lg-0">
        <div class="block">
          <h4>Admin Pages</h4>
          <ul>
            <li><a href="category.html">Category</a></li>
            <li><a href="single.html">Single Page</a></li>
            <li><a href="store.html">Store Single</a></li>
            <li><a href="single-blog.html">Single Post</a>
            </li>
            <li><a href="blog.html">Blog</a></li>



          </ul>
        </div>
      </div>
      <!-- Promotion -->
      <div class="col-lg-4 col-md-7">
        <!-- App promotion -->
        <div class="block-2 app-promotion">
          <div class="mobile d-flex">
            <a href="">
              <!-- Icon -->
              <img src="../images/footer/phone-icon.png" alt="mobile-icon">
            </a>
            <p>Get the Dealsy Mobile App and Save more</p>
          </div>
          <div class="download-btn d-flex my-3">
            <a href="#"><img src="../images/apps/google-play-store.png" class="img-fluid" alt=""></a>
            <a href="#" class=" ml-3"><img src="../images/apps/apple-app-store.png" class="img-fluid" alt=""></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Container End -->
</footer>
<!-- Footer Bottom -->
<footer class="footer-bottom">
  <!-- Container Start -->
  <div class="container">
    <div class="row">
      <div class="col-sm-6 col-12">
        <!-- Copyright -->
        <div class="copyright">
          <p>Copyright © <script>
              var CurrentYear = new Date().getFullYear()
              document.write(CurrentYear)
            </script>. All Rights Reserved, theme by <a class="text-primary" href="https://themefisher.com" target="_blank">themefisher.com</a></p>
        </div>
      </div>
      <div class="col-sm-6 col-12">
        <!-- Social Icons -->
        <ul class="social-media-icons text-right">
          <li><a class="fa fa-facebook" href="https://www.facebook.com/themefisher" target="_blank"></a></li>
          <li><a class="fa fa-twitter" href="https://www.twitter.com/themefisher" target="_blank"></a></li>
          <li><a class="fa fa-pinterest-p" href="https://www.pinterest.com/themefisher" target="_blank"></a></li>
          <li><a class="fa fa-vimeo" href=""></a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- Container End -->
  <!-- To Top -->
  <div class="top-to">
    <a id="top" class="" href="#"><i class="fa fa-angle-up"></i></a>
  </div>
</footer>

<!-- JAVASCRIPTS -->
<script src="../plugins/jQuery/jquery.min.js"></script>
<script src="../plugins/bootstrap/js/popper.min.js"></script>
<script src="../plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="../plugins/bootstrap/js/bootstrap-slider.js"></script>
  <!-- tether js -->
<script src="../plugins/tether/js/tether.min.js"></script>
<script src="../plugins/raty/jquery.raty-fa.js"></script>
<script src="../plugins/slick-carousel/slick/slick.min.js"></script>
<script src="../plugins/jquery-nice-select/js/jquery.nice-select.min.js"></script>
<script src="../plugins/fancybox/jquery.fancybox.pack.js"></script>
<script src="../plugins/smoothscroll/SmoothScroll.min.js"></script>
<!-- google map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
<script src="../plugins/google-map/gmap.js"></script>
<script src="../js/script.js"></script>

</body>

</html>