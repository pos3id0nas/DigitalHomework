<?php

session_start();
include("session.php");

if(isset($_POST['btndel']){
$username = $_POST['username_delete'];
$sql = mysql_query("DELETE FROM user WHERE user_id='$username'");

if($sql){
    echo "Deleted";
}else{
  header('location:index.php');
}
}
?>