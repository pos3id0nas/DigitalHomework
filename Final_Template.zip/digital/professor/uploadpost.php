<?php
date_default_timezone_set('UTC');
include("../session.php");

$ext="";
$file="";
if(isset($_REQUEST["submit"])AND $_FILES["myfile"]["size"]>0 )
{
    
    $file=$_FILES["myfile"];
    checkFileExtension();
    checkFileSize();
    uplodFileToDestination();
	
}
else if(isset($_REQUEST["submit"])AND $_FILES["myfile"]["size"]==0 )
{
	$destination=NULL;
	insertInTable($destination);
	exit();
}

function checkFileExtension()
{
	global $ext;
    $filename=$_FILES["myfile"]["name"];
    $tmparray = explode(".",$filename);
    $ext = strtolower(end($tmparray));
    $extarray=["jpg","jpeg","png"];
    if(!in_array($ext,$extarray))
    {
        echo "Invalid file size given";
        exit();
    }
}
function checkFileSize()
{
   $onemb=10000000;
   if($_FILES["myfile"]["size"]>($onemb))
   {
       echo $_FILES["myfile"]["size"];
        echo "file too large";
        exit();
   }
}
function uplodFileToDestination()
{
    global $file,$ext;
    $newname = uniqid('',true).".".$ext;
    $filepath = $_FILES["myfile"]["tmp_name"];
    $destination="../images/posts/".$newname;
    move_uploaded_file($filepath,$destination);
    insertInTable($destination);
    exit();
}
function insertInTable($img)
{
    global $conn;
	$author= $_SESSION["fullname"];
    $postdate = date("d/m/Y");
    $title = $conn->real_escape_string($_REQUEST["title"]);
    $sdesc = $conn->real_escape_string($_REQUEST["sdesc"]);
    $fdesc = $conn->real_escape_string($_REQUEST["fdesc"]);
    $post_lesson= $_REQUEST["lessonname"];
    $query = "INSERT INTO posts(author, post_lesson, title, sdesc, fdesc, img, postdate) values(?,?,?,?,?,?,?)";
	$stmt = $conn->prepare($query);
	if($stmt = $conn->prepare($query)) { 
    //$result = $conn->query($query);
	$stmt->bind_param("sssssss", $author, $post_lesson, $title, $sdesc, $fdesc, $img, $postdate);
	$stmt->execute();
	if($conn->affected_rows==1)
        header("Location: ../professor/profile.php");
    }
    else{
        echo $conn->error;
	}
}
?>