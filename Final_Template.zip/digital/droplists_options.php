<?php
	
include('errors.php');

	$lesquery = "SELECT * FROM lessons Order by lessonname";
  	$resultl = mysqli_query($conn, $lesquery);
	
	$autquery = "SELECT * FROM authors Order by fullname";
  	$resultf = mysqli_query($conn, $autquery);
	

?>