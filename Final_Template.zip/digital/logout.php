<?php

	include("errors.php");
	session_start();
	
	echo "<script>alert('Logout Successful!!!')</script>";
	
	
	setcookie(session_name(), '', 600);
	session_unset();
	session_destroy();
	$_SESSION = array();
	
	header( "refresh:1; url=index.php" ); 
?>